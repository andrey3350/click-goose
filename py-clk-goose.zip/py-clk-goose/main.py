# ultra-goose prj main file.
# Author: Andrey3350 -> https://github.com/andrey3350
# Designer: Saturnian-SUS -> https://github.com/saturnian-sus
#



from tkinter import *
from PIL import Image, ImageTk
import os
import mouse

# === Параметры ===
DUCK_IMG = "idle.png"  # утка с закрытым клювом
DUCK_QUACK_IMG = "click.png"  # утка с открытым клювом
SAVE_FILE = "clicks.txt"


# === Загрузка счетчика ===

def load_clicks():
    if os.path.exists(SAVE_FILE):
        try:
            return int(open(SAVE_FILE).read())
        finally:
            return 0
    return 0


# === Сохранение счетчика ===
def save_clicks(c):
    with open(SAVE_FILE, "w") as f:
        f.write(str(c))


# === Окно ===
root = Tk()
root.overrideredirect(True)  # убираем рамки
root.wm_attributes("-topmost", True)  # поверх всех окон
root.wm_attributes("-transparentcolor", "pink")  # делаем определённый цвет прозрачным (Windows only)
root.config(bg="pink")  # этот цвет станет невидимым

# === Переменные ===
clicks = load_clicks()

# === Загрузка изображений ===
idle_img = Image.open(DUCK_IMG)
quack_img = Image.open(DUCK_QUACK_IMG)

idle = ImageTk.PhotoImage(idle_img)
quack = ImageTk.PhotoImage(quack_img)

click_label = Label(root, text=str(clicks), font=('Helvetica', 16, 'bold'), )
click_label.pack()
label = Label(root, image=idle, bd=0, bg="pink")
label.pack()


# === Обработчик событий ===
def event_listener(event):
    if isinstance(event, mouse.ButtonEvent) and event.event_type != 'up':
        clicked()


# === Реакция на клик ===
def clicked():
    global clicks
    clicks += 1
    save_clicks(clicks)
    label.config(image=quack)
    click_label['text'] = str(clicks)
    root.after(150, lambda: label.config(image=idle))


# === Движение мышкой (перетаскивание) ===
def start_move(event):
    root.x = event.x
    root.y = event.y


# === Передвижение за мышкой ===
def do_move(event):
    deltax = event.x - root.x
    deltay = event.y - root.y
    x = root.winfo_x() + deltax
    y = root.winfo_y() + deltay
    root.geometry(f"+{x}+{y}")

# === Закрытие приложения ===
def close(event):
    root.destroy()

mouse.hook(event_listener)
label.bind("<Button-3>", start_move)  # правая кнопка мыши — начало перетаскивания
label.bind("<B3-Motion>", do_move)  # движение мыши с правой кнопкой
label.bind("<Double-Button-3>", close)  # выход при двойном клике по картинке

root.mainloop()
